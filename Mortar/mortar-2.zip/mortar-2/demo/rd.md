this demo for testing if DLL compiled correctly 
